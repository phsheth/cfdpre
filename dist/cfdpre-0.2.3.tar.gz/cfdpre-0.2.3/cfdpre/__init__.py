# __init__.py

from .main import yhgrcalc