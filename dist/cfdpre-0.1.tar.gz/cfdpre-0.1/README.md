# CFD-Pre
CFD PreProcessing Library. 

Provides the following functionality:
1. Calculate Boundary Layer Mesh dimensions.




## Project Log
January 2025:
1. Created Library


## Project Road Map:

1. Documentation for existing functionality.
2. Include example data within library.